About MetaAnalysisBetaUnionCaCo.jar
1. MetaAnalysisBetaUnionCaCo.jar is the java program which conducts GWAS meta-analysis.


Usage of MetaAnalysisBetaUnionCaCo.jar
1. MetaAnalysisBetaUnionCaCo.jar requires Java environment.
2. MetaAnalysisBetaUnionCaCo.jar requires commons-math-1.2.jar. Place it to your external libraly of jre.
3. MetaAnalysisBetaUnionCaCo.jar requires P_Chi_CorresTable_high.txt at the working directory.
4. Command: "java -jar MetaAnalysisBetaUnionCaCo.jar -prefix ExampleFile -noGCeach"


Arguments
1. -prefix : prefix of the input file
2. -noGCeach : Do not perform GC correction for each GWAS (or GC correction with lamndaGC=1)


The format of input file
1. A matrix file with one row per SNP with 7*No.GWAS columns
2. Seven columns for each GWAS association results
  Col 1 : No. cases
  Col 2 : No. controls
  Col 3 : Allele 1 frequency in cases
  Col 4 : Allele 1 frequency in controls
  Col 5 : Beta of Allele 1
  Col 6 : SE for Beta
  Col 7 : P-value
3. For missing value, please input "-99".
4. Need at least one row which include "-99" for all columns.


Output files.
1. MetaAnalysisBetaUnionCaCo.jar outputs two files
 (1) hoge_GCed.txt : This file includes GC corrected statistics of input file (by lambdaGC calculated based on each GWAS results).
 (2) hoge_GCed_Meta_res.txt : This file includes GWAS meta-analysis resutls of (1).
   Col 1 : No. studies in GWAS meta-analysis
   Col 2 : No. total cases
   Col 3 : No. total controls
   Col 4 : Allele 1 frequency in total cases
   Col 5 : Allele 1 frequency in total controls
   Col 6 : Beta of Allele 1 (by a inverse-variance method assuming sfix-effect model)
   Col 7 : SE for Beta (by a inverse-variance method assuming sfix-effect model)
   Col 8 : P-value (by a inverse-variance method assuming sfix-effect model)
   Col 9 : P-value (by Z-value based meta-analysis)
 (3) hoge_Meta_log.txt : This file includes log information.


Any questions to Yukinori Okada (http://plaza.umin.ac.jp/~yokada/datasource/software.htm   yokada@broadinstitute.org)


